package demo.clinic.model;


public class MedicalstaffDto {
	
	private String stafCode;
	private String stafId;
	private String stafJobTitle;
	private String stafName;
	
	public MedicalstaffDto() {

	}

	public String getStafCode() {
		return stafCode;
	}

	public void setStafCode(String stafCode) {
		this.stafCode = stafCode;
	}

	public String getStafId() {
		return stafId;
	}

	public void setStafId(String stafId) {
		this.stafId = stafId;
	}

	public String getStafJobTitle() {
		return stafJobTitle;
	}

	public void setStafJobTitle(String stafJobTitle) {
		this.stafJobTitle = stafJobTitle;
	}

	public String getStafName() {
		return stafName;
	}

	public void setStafName(String stafName) {
		this.stafName = stafName;
	}

	
}
